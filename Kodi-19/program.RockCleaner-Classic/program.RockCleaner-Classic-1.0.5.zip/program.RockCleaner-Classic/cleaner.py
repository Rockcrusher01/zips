
import urllib.request, urllib.parse, urllib.error,urllib.request,re,uuid, time
import xbmc,xbmcgui,xbmcvfs,xbmcplugin,xbmcaddon,os,shutil,sqlite3,json
import os,sys


thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'program.RockCleaner-Classic')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')
addon_id = 'program.RockCleaner-Classic'
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi
    
def mainMenu():
    addItem('[COLOR red][B][I]Clear Cache[/I][/B][/COLOR]','url', 1,os.path.join(mediaPath, "cache.png"))
    addItem('[COLOR red][B][I]Delete Thumbnails[/I][/B][/COLOR]', 'url', 2,os.path.join(mediaPath, "thumbs.png"))
    addItem('[COLOR red][B][I]Purge Packages[/I][/B][/COLOR]', 'url', 3,os.path.join(mediaPath, "packages.png"))
    addItem('[COLOR red][B][I]System Clean[/I][/B][/COLOR]', 'url', 4,os.path.join(mediaPath, "System.png"))
    addItem('[COLOR red][B][I]Update[/I][/B][/COLOR]', 'url', 5,os.path.join(mediaPath, "update.png"))

def addLink(name, url, iconimage):
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty( "Fanart_Image", fanart )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok

def addDir(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty( "Fanart_Image", fanart )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addItem(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty( "Fanart_Image", fanart )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok
      
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param   
	
def setupCacheEntries():
    entries = 5 #make sure this refelcts the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries


def clearCache():
    
    if os.path.exists(cachePath)==True:    
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("[COLOR red][B][I]Delete Kodi Cache Files[/I][/B][/COLOR]", str(file_count) + "[COLOR red][B][I] files found.[/I][/B][/COLOR]", "[COLOR red][B][I]Do you want to delete them?[/I][/B][/COLOR]"):
                
                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f =="kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "matrixx.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if os.path.exists(tempPath)==True:    
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                dialog = xbmcgui.Dialog()
                if dialog.yesno("[COLOR red][B][I]Delete Kodi Temp Files[/I][/B][/COLOR]", str(file_count) + "[COLOR red][B][I] files found.[/I][/B][/COLOR]", "[COLOR red][B][I]Do you want to delete them?[/I][/B][/COLOR]"):
                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f =="kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "matrixx.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("[COLOR red][B][I]Delete ATV2 Cache Files[/I][/B][/COLOR]", str(file_count) + "[COLOR red][B][I] files found in 'Other'", "Do you want to delete them?[/I][/B][/COLOR]"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("[COLOR red][B][I]Delete ATV2 Cache Files[/I][/B][/COLOR]", str(file_count) + "[COLOR red][B][I] files found in 'LocalAndRental'[/I][/B][/COLOR]", "[COLOR red][B][I]Do you want to delete them?[/I][/B][/COLOR]"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass    
                
    cacheEntries = setupCacheEntries()
                                         
    for entry in cacheEntries:
        clear_cache_path = xbmc.translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:    
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:

                    dialog = xbmcgui.Dialog()
                    if dialog.yesno("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]",str(file_count) + "[COLOR red][B][I]%s [/B][/I][COLOR red][B][I]cache files found[/I][/B][/COLOR]"%(entry.name), "[COLOR red][B][I]Do you want to delete them?[/I][/B][/COLOR]"):
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                            
                else:
                    pass
                

    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]Done Clearing All Cache files[/I][/B][/COLOR]")
    
    
def deleteThumbnails():
    
    if os.path.exists(thumbnailPath)==True:  
            dialog = xbmcgui.Dialog()
            if dialog.yesno("[COLOR red][B][I]Delete Thumbnails[/I][/B][/COLOR]", "[COLOR red][B][I]This option deletes all kodi thumbnails[/I][/B][/COLOR]", "[COLOR red][B][I]Are you sure you want to do this?[/I][/B][/COLOR]"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass                
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    os.unlink(text13)
        
    dialog.ok("[COLOR red][B][I]Restart Kodi[/I][/B][/COLOR]", "[COLOR red][B][I]Please restart Kodi to rebuild thumbnail library.[/I][/B][/COLOR]")
        
def purgePackages():
    
    purgePath = xbmc.translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
    if dialog.yesno("[COLOR red][B][I]Delete Package Cache Files[/I][/B][/COLOR]", "[COLOR red][B][I]%d [/B][/I][COLOR red][B][I]packages found.[/I][/B][/COLOR]"%file_count, "[COLOR red][B][I]Do you want to Delete Them?[/I][/B][/COLOR]"):  
        for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                dialog = xbmcgui.Dialog()
                dialog.ok("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]Deleting Packages all done.[/I][/B][/COLOR]")
            else:
                dialog = xbmcgui.Dialog()
                dialog.ok("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]No Packages to Purge.[/I][/B][/COLOR]") 
                
def ForceUpdate():
  dialog = xbmcgui.Dialog()
  if dialog.yesno("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]Update All Add-ons.[/I][/B][/COLOR]", "[COLOR red][B][I]And Repositorys ?[/I][/B][/COLOR]"):
     xbmc.executebuiltin('UpdateAddonRepos()')
     xbmc.executebuiltin('UpdateLocalAddons()') 
  dialog = xbmcgui.Dialog()
  dialog.ok("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]Updating All Addons and Repos.[/I][/B][/COLOR]")  
  
  def setupCacheEntries():
    entries = 5 #make sure this refelcts the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries

def autocleannow():

  dialog = xbmcgui.Dialog()
  if dialog.yesno("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]System Clean[/I][/B][/COLOR]", "[COLOR red][B][I]Clear Cache, Delete Thumbnails, Purge Packages[/I][/B][/COLOR]","[COLOR red][B][I]Are You Sure ?[/I][/B][/COLOR]"):
  		
    if os.path.exists(cachePath)==True:    
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "matrixx.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
				
    if os.path.exists(tempPath)==True:    
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                    for f in files:
                        try:
                            if (f == "kodi.log" or f == "kodi.old.log" or f == "spmc.log" or f == "spmc.old.log" or f == "matrixx.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass    
                
    cacheEntries = setupCacheEntries()
                                         
    for entry in cacheEntries:
        clear_cache_path = xbmc.translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:    
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                            
                else:
                    pass
        
    if os.path.exists(thumbnailPath)==True:  
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    try:
        os.unlink(text13)
    except OSError:
        pass
		
    purgePath = xbmc.translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
    for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            else:
                dialog = xbmcgui.Dialog()
                dialog.ok("[COLOR red][B][I]ROCK CLEANER CLASSIC[/I][/B][/COLOR]", "[COLOR red][B][I]System Clean All Done Please Reboot Kodi.[/I][/B][/COLOR]")
                
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()
       
elif mode==1:
		clearCache()
        
elif mode==2:
        deleteThumbnails()

elif mode==3:
		purgePackages()
		
elif mode==4:
		autocleannow()
		
elif mode==5:
		ForceUpdate()



xbmcplugin.endOfDirectory(int(sys.argv[1]))

